# Complexity Analysis

n = number of departments (nodes) = 8, h = tree height = 3, b = max branching factor = 3.

## Structural analysis
| Item | Result |
|---|---|
| Tree type | General (n-ary) rooted tree; each node keeps a list of children |
| Number of nodes / edges | 8 nodes / 7 edges |
| Tree height | **3 edges (4 levels)**: CEO -> IT -> Development -> Frontend/Backend |
| Leaves | HR, Finance, Testing, Frontend, Backend |
| Widest level | Level 1 (3 nodes: HR, Finance, IT) |

## Traversal behaviour
Level-order (BFS) uses a FIFO queue and visits all nodes of one level before the next:
CEO | HR, Finance, IT | Development, Testing | Frontend, Backend.
- Output groups directly into management layers, which matches how reporting lines are read.
- Every node is enqueued and dequeued exactly once -> n visits.
- Maximum queue size was 3 (widest level), i.e. O(w) auxiliary space, w = max level width.

## Time and space complexity of selected operations
| Operation | Time | Space | Note |
|---|---|---|---|
| Build tree (n-1 add operations, dict lookup) | O(n) | O(n) | dictionary gives O(1) parent lookup |
| Level-order traversal | O(n) | O(w) queue | each node visited once |
| Tree height (recursive DFS) | O(n) | O(h) call stack | |
| Sort names once (for binary search) | O(n log n) | O(n) | one-time cost |
| Linear search | Best O(1), Avg/Worst O(n) | O(1) | no sorting needed |
| Binary search | Best O(1), Avg/Worst O(log n) | O(1) | needs sorted array |
| Finding a name by tree search (BFS/DFS) | O(n) | O(w) / O(h) | tree is not ordered by name |
| Insert new department under known parent | O(1) with dict | O(1) | |

## Search comparisons (measured)
| Key | Linear | Binary |
|---|---|---|
| IT | 4 | 3 |
| Backend | 8 | 3 |
| Testing | 6 | 4 |
| Marketing (absent) | 8 | 4 |
| **Total** | **26** | **14** |

Binary search needed at most 4 = floor(log2 8) + 1 comparisons; linear needed up to 8 = n.
Average: linear 6.5 vs binary 3.5 per query. For n = 8 the gap is modest, but it grows
quickly: for n = 1,000,000 linear may need 1,000,000 comparisons, binary only about 20.

# Organisational Hierarchy - Tree, BFS, Linear vs Binary Search
Run: `python3 org_hierarchy.py` (reads input_data.txt, regenerates output.txt, trace_table.md, comparison_table.md)

| File | Content |
|---|---|
| org_hierarchy.py | Source code |
| input_data.txt | Input data (edges + search keys) |
| output.txt | Program output |
| trace_table.md | BFS and binary-search trace tables |
| complexity_analysis.md | Height, traversal, complexity analysis |
| comparison_table.md | Linear vs Binary comparisons |
| conclusion.md | Final conclusion |

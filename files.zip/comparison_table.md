# Linear vs Binary Search Comparison

| Search key | Found? | Linear position | Linear comparisons | Binary position | Binary comparisons |
|---|---|---|---|---|---|
| IT | Yes | 3 | 4 | 6 | 3 |
| Backend | Yes | 7 | 8 | 0 | 3 |
| Testing | Yes | 5 | 6 | 7 | 4 |
| Marketing | No | -1 | 8 | -1 | 4 |
| **Total** | | | **26** | | **14** |

# Final Conclusion

1. **Representation.** A general (n-ary) tree with a child list per node models the hierarchy
   exactly (CEO -> HR, Finance, IT; IT -> Development, Testing; Development -> Frontend, Backend).
   It has 8 nodes and height 3.
2. **Traversal.** Level-order traversal gave CEO, HR, Finance, IT, Development, Testing,
   Frontend, Backend, grouped by management level. It runs in O(n) with a queue.
3. **Searching.** With a sorted array, Binary Search used 14 comparisons in total against 26
   for Linear Search over four queries (three hits and one miss). Binary is O(log n); Linear is O(n).
4. **Suitability.**
   - The tree is **highly suitable for organisational reporting**: parent/child links represent
     reporting lines, and level, height and subtree queries are natural.
   - The tree alone is **not ideal for searching by name**, since it is not ordered by name and
     lookup costs O(n).
   - Best design: keep the tree for reporting, and add a sorted array (Binary Search, O(log n)) or a
     hash map (O(1) average) for fast department lookup. The sorted array must be rebuilt in
     O(n log n) after changes; a hash map or balanced BST avoids that cost in dynamic organisations.
   - For only 8 departments any method is fast; the choice matters as the company grows.

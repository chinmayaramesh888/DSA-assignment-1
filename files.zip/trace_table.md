# Trace Tables

## Trace Table 1: Level-order (BFS) traversal

| Step | Dequeued node | Level | Children enqueued | Queue after step |
|---|---|---|---|---|
| 1 | CEO | 0 | HR, Finance, IT | HR, Finance, IT |
| 2 | HR | 1 | - | Finance, IT |
| 3 | Finance | 1 | - | IT |
| 4 | IT | 1 | Development, Testing | Development, Testing |
| 5 | Development | 2 | Frontend, Backend | Testing, Frontend, Backend |
| 6 | Testing | 2 | - | Frontend, Backend |
| 7 | Frontend | 3 | - | Backend |
| 8 | Backend | 3 | - | (empty) |

Sorted array (index 0-7): ['Backend', 'CEO', 'Development', 'Finance', 'Frontend', 'HR', 'IT', 'Testing']

## Trace Table 2: Binary search for 'IT'

| Probe | low | high | mid | arr[mid] | Decision |
|---|---|---|---|---|---|
| 1 | 0 | 7 | 3 | Finance | go right |
| 2 | 4 | 7 | 5 | HR | go right |
| 3 | 6 | 7 | 6 | IT | found |

## Trace Table 3: Binary search for 'Backend'

| Probe | low | high | mid | arr[mid] | Decision |
|---|---|---|---|---|---|
| 1 | 0 | 7 | 3 | Finance | go left |
| 2 | 0 | 2 | 1 | CEO | go left |
| 3 | 0 | 0 | 0 | Backend | found |

## Trace Table 4: Binary search for 'Testing'

| Probe | low | high | mid | arr[mid] | Decision |
|---|---|---|---|---|---|
| 1 | 0 | 7 | 3 | Finance | go right |
| 2 | 4 | 7 | 5 | HR | go right |
| 3 | 6 | 7 | 6 | IT | go right |
| 4 | 7 | 7 | 7 | Testing | found |

## Trace Table 5: Binary search for 'Marketing'

| Probe | low | high | mid | arr[mid] | Decision |
|---|---|---|---|---|---|
| 1 | 0 | 7 | 3 | Finance | go right |
| 2 | 4 | 7 | 5 | HR | go right |
| 3 | 6 | 7 | 6 | IT | go right |
| 4 | 7 | 7 | 7 | Testing | go left |


"""
Organisational hierarchy: General Tree + Level-order traversal
+ Linear Search vs Binary Search on department names.
Reads input_data.txt, writes output.txt, trace_table.md, comparison_table.md
"""
from collections import deque

# ---------------------------------------------------------------- (a) TREE
class Node:
    def __init__(self, name):
        self.name = name
        self.children = []          # general tree: any number of children

class OrgTree:
    def __init__(self):
        self.nodes = {}             # name -> Node  (O(1) lookup while building)
        self.root = None

    def add(self, parent, child):
        if parent not in self.nodes:
            self.nodes[parent] = Node(parent)
            if self.root is None:
                self.root = self.nodes[parent]
        if child not in self.nodes:
            self.nodes[child] = Node(child)
        self.nodes[parent].children.append(self.nodes[child])

    def level_order(self):
        """BFS with a queue. Returns (levels, trace rows)."""
        levels, trace = [], []
        q = deque([(self.root, 0)])
        step = 0
        while q:
            node, lvl = q.popleft()
            step += 1
            if lvl == len(levels):
                levels.append([])
            levels[lvl].append(node.name)
            for c in node.children:
                q.append((c, lvl + 1))
            trace.append((step, node.name, lvl,
                          ", ".join(c.name for c in node.children) or "-",
                          ", ".join(n.name for n, _ in q) or "(empty)"))
        return levels, trace

    def height(self, node=None):
        node = node or self.root
        if not node.children:
            return 0
        return 1 + max(self.height(c) for c in node.children)

# ------------------------------------------------------------ (b) SEARCHING
def linear_search(arr, key):
    comps = 0
    for i, v in enumerate(arr):
        comps += 1
        if v.lower() == key.lower():
            return i, comps
    return -1, comps

def binary_search(arr, key, trace=None):
    lo, hi, comps = 0, len(arr) - 1, 0
    key = key.lower()
    while lo <= hi:
        mid = (lo + hi) // 2
        comps += 1                              # one 3-way comparison per probe
        v = arr[mid].lower()
        if trace is not None:
            trace.append((lo, hi, mid, arr[mid],
                          "found" if v == key else ("go right" if v < key else "go left")))
        if v == key:
            return mid, comps
        if v < key: lo = mid + 1
        else:       hi = mid - 1
    return -1, comps

# --------------------------------------------------------------------- MAIN
def read_input(path):
    edges, queries = [], []
    for line in open(path):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            p, cs = line.split(":")
            edges += [(p.strip(), c.strip()) for c in cs.split(",")]
        else:
            queries.append(line)
    return edges, queries

def main():
    out, tr, cmp_ = [], [], []
    P = out.append
    edges, queries = read_input("input_data.txt")

    tree = OrgTree()
    for p, c in edges:
        tree.add(p, c)

    P("=" * 60); P("(a) LEVEL-ORDER TRAVERSAL OF ORGANISATION TREE"); P("=" * 60)
    levels, trace = tree.level_order()
    for i, lv in enumerate(levels):
        P(f"Level {i}: " + ", ".join(lv))
    flat = [n for lv in levels for n in lv]
    P("\nLevel-order sequence : " + " -> ".join(flat))
    P(f"Total nodes          : {len(flat)}")
    P(f"Tree height          : {tree.height()} edges ({len(levels)} levels)")
    P(f"Leaf departments     : " + ", ".join(n for n, nd in tree.nodes.items() if not nd.children))

    linear_list = flat                       # unsorted (BFS order)
    binary_list = sorted(flat, key=str.lower)  # sorted for binary search
    P("\n" + "=" * 60); P("(b) SEARCHABLE REPRESENTATION"); P("=" * 60)
    P("Unsorted list (for Linear Search): " + str(linear_list))
    P("Sorted list   (for Binary Search): " + str(binary_list))
    P("\n{:<12}{:<10}{:<16}{:<10}{:<16}".format(
        "Search key", "Linear", "Linear comps", "Binary", "Binary comps"))
    P("-" * 64)

    cmp_ += ["| Search key | Found? | Linear position | Linear comparisons | Binary position | Binary comparisons |",
             "|---|---|---|---|---|---|"]
    bin_traces = {}
    tl, tb = 0, 0
    for k in queries:
        li, lc = linear_search(linear_list, k)
        t = []
        bi, bc = binary_search(binary_list, k, t)
        bin_traces[k] = t
        tl += lc; tb += bc
        P("{:<12}{:<10}{:<16}{:<10}{:<16}".format(k, li, lc, bi, bc))
        cmp_.append(f"| {k} | {'Yes' if li >= 0 else 'No'} | {li} | {lc} | {bi} | {bc} |")
    cmp_.append(f"| **Total** | | | **{tl}** | | **{tb}** |")
    P(f"\nTotal comparisons -> Linear: {tl}, Binary: {tb}")

    # trace tables
    tr.append("## Trace Table 1: Level-order (BFS) traversal\n")
    tr.append("| Step | Dequeued node | Level | Children enqueued | Queue after step |")
    tr.append("|---|---|---|---|---|")
    for s in trace:
        tr.append("| " + " | ".join(map(str, s)) + " |")
    tr.append(f"\nSorted array (index 0-7): {binary_list}\n")
    n = 2
    for k, t in bin_traces.items():
        tr.append(f"## Trace Table {n}: Binary search for '{k}'\n"); n += 1
        tr.append("| Probe | low | high | mid | arr[mid] | Decision |")
        tr.append("|---|---|---|---|---|---|")
        for i, row in enumerate(t, 1):
            tr.append(f"| {i} | " + " | ".join(map(str, row)) + " |")
        tr.append("")

    open("output.txt", "w").write("\n".join(out) + "\n")
    open("trace_table.md", "w").write("# Trace Tables\n\n" + "\n".join(tr) + "\n")
    open("comparison_table.md", "w").write("# Linear vs Binary Search Comparison\n\n" + "\n".join(cmp_) + "\n")
    print("\n".join(out))

if __name__ == "__main__":
    main()
